/**
* CI3825: Sistemas de Operación
* Valeria Vera Herrera
* 16-11233
*
* Estructure "Tuple". Es el tipo de estructura del cual
* están hechos los arreglos dinámicos.
*/

typedef struct Tuple {
    int keyN;
    char *keyA;
    char *name;
    int number;
}
Tuple;